package appli.todolistjx;

public class InscriptionControler {
}
